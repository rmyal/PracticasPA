/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;

/**
 *
 * @author anshenoy
 */
import java.util.Scanner;

public class ChkOddEven {

    public static void main(String args[]) {

        Scanner in = new Scanner(System.in);
        int num;
        System.out.println("Escribe un número del 1-10: ");
        num = in.nextInt();
        if(num%2==0){
            System.out.println("Es par");
        }else{
            System.out.println("Es impar");
        }
    }
}

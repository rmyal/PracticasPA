
package casting01;

public class Casting01 {
    public static void main(String[] args) {
        /*Nos muestra imcompatilidad del dato, porque 128 es el primer valor que puede entrar
          en un tipo short, para quitar ese raro, se puede igual a 127*/
        byte dato=127;
        
        //Declare and initialize a short with a value of 128
        //Create a print statement that casts this short to a byte
        short otroDato=128;
        byte miByte=0;
        miByte=(byte)otroDato;
        System.out.println("la variable short en byte es"+miByte);
        //Declare and initialize a byte with a value of 127
        //Add 1 to this variable and print it
        //Add 1 to this variable again and print it again
        byte imp=127;
        System.out.println(imp+1);
        System.out.println(imp+1);

        
        
        
    }    
}


package chickens01;

public class Chickens01 {
    public static void main(String[] args) {
        //Put yout code here
        int EggPerChicken=4;
        int ChickenCount=8;
        int totalEggs=0;
        //Lunes, recoge huevos
        totalEggs=ChickenCount*EggPerChicken;
        //Lunes,tiene 1 gallina más
        ChickenCount=ChickenCount+1;
        //Martes, Recoge huevos
        totalEggs=totalEggs+(ChickenCount*EggPerChicken);
        //Miércoles, un zorro se come la mitad de las gallina
        ChickenCount=ChickenCount/2;
        //Miércoles, recoge los huevos
        totalEggs=totalEggs+(ChickenCount*EggPerChicken);
        System.out.println(totalEggs);
    }   
}

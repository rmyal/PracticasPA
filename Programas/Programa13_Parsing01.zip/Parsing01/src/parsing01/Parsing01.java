package parsing01;

public class Parsing01 {
    public static void main(String[] args) {
        //Declare and intitialize 3 Strings: shirtPrice, taxRate, and gibberish
        String shirtPrice="15";
        String taxRate="0.05";
        String Gibberish="887ds7nds87dsfs";

        //Parse shirtPrice and taxRate, and print the total tax
        int precio= Integer.parseInt(shirtPrice);
        int impuesto= Integer.parseInt(taxRate);
        int total=precio*impuesto;
        //Try to parse gibberish as an int
        int cadena= Integer.parseInt(Gibberish);
    }
    
}

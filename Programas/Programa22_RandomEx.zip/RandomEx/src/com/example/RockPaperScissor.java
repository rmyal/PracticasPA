/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;
import java.util.Random;


public class RockPaperScissor {

    public static void main(String[] args) {
        Random rdn=new Random();
        int tiro=rdn.nextInt(3);
        if(tiro==0){
            System.out.println("Piedra");
        }else if(tiro==1){
            System.out.println("Papel");
        }else{
            System.out.println("Tijeras");
        }

    }
}


package Tip02;
public class CalculatorTest {
    public int P1=10;
    public int P2=12;
    public int P3=9;
    public int P4=8;
    public int P5=7;
    public int P6=15;
    public int P7=11;
    public int P8=30;
    public static void main(String[] args) { 
        //Instantiate a Calculator object
        Calculator calc=new Calculator();
        //Access the Calculator object's fields and methods
        //to find the total for each member of the birthday part
        
        calc.findTotal();
        
        
    }
}


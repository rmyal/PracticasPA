
package Tip02;

public class Calculator {
    public double tax = .05;
    public double tip = .15;
    public double total; //Change tax and tip if you prefer different values
    public double originalPrice = 0;
    
    public void findTotal(){
        CalculatorTest precio=new CalculatorTest();
        total=(precio.P1*tax)+(precio.P1*tip)+precio.P1;
        System.out.println("El pago de la persona 1 con impuestos y propina es: "+total);
        
        //Persona 2
        total=(precio.P2*tax)+(precio.P2*tip)+precio.P2;
        System.out.println("El pago de la persona 2 con impuestos y propina es: "+total);
        
        //Persona 3
        total=(precio.P3*tax)+(precio.P3*tip)+precio.P3;
        System.out.println("El pago de la persona 3 con impuestos y propina es: "+total);
        
        //Persona 4
        total=(precio.P4*tax)+(precio.P4*tip)+precio.P4;
        System.out.println("El pago de la persona 4 con impuestos y propina es: "+total);
        
        //Persona 5
        total=(precio.P5*tax)+(precio.P5*tip)+precio.P5;
        System.out.println("El pago de la persona 5 con impuestos y propina es: "+total);
        
        //Persona 6
        total=(precio.P6*tax)+(precio.P6*tip)+precio.P6;
        System.out.println("El pago de la persona 6 con impuestos y propina es: "+total);
        
        //Persona 7
        total=(precio.P7*tax)+(precio.P7*tip)+precio.P7;
        System.out.println("El pago de la persona 7 con impuestos y propina es: "+total);
        
        //Persona 8
        total=(precio.P8*tax)+(precio.P8*tip)+precio.P8;
        System.out.println("El pago de la persona 8 con impuestos y propina es: "+total);
    }
}

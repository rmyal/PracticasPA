
package shoppingcart02;

public class ShoppingCart02 {
    public static void main(String[] args) {
        String custName = "Alex";
        String itemDesc = " 2 tacos";
        String message = custName+" quiere comprar "+itemDesc;
        System.out.println(message);
        // Declare and initialize numeric fields: price, tax, quantity.   
        double price=10;
        double tax=5;
        int quantity=2;       
        // Declare and assign a calculated totalPrice
        double totalPrice=(quantity*price)+tax;
        
        // Modify message to include quantity 
        
        System.out.println("Alex va a pagar "+totalPrice+" por su compra");
        
        // Print another message with the total cost
        
    }    
}

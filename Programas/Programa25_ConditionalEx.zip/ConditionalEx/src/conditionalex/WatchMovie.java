/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conditionalex;

import java.util.Scanner;

/**
 *
 * @author anshenoy
 */
public class WatchMovie {

    public static void main(String args[]) {
        System.out.print("Escribe el precio del boleto: \n");
           Scanner tk=new Scanner(System.in);
           int precio=tk.nextInt();
           System.out.print("Escribe la clasificación de la película: \n");
           int clas=tk.nextInt();
           if(precio<=12 && clas==5){
               System.out.println("Quiero verla");
           }else{
               System.out.println("No quiero verla");
           }

    }
}

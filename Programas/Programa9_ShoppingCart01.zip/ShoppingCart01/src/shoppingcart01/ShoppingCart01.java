
package shoppingcart01;

public class ShoppingCart01 {
    public static void main(String[] args) {
        // Declare and initialize String variables.  Do not initialize message yet.
        String custName="Alex quiere comprar";
        String itemDesc=" unos cheetos";
        String message=custName+itemDesc;
        System.out.println(message);
        
        
        
        // Assign the message variable 
        
        
        // Print and run the code
        
    }
}

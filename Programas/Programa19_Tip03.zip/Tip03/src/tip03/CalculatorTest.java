
package tip03;

public class CalculatorTest {
    public static void main(String[] args) {
        int P1=10;
        int P2=12;
        int P3=9;
        int P4=8;
        int P5=7;
        int P6=15;
        int P7=11;
        int P8=30;
       Calculator calc = new Calculator();
       //Use the Calculator object and arguments supplied to findTotal()
       //to print the total for each person

       calc.findTotal("Alan",P1);
       calc.findTotal("Ulises",P2);
       calc.findTotal("Alan",P3);
       calc.findTotal("Ulises",P4);
       calc.findTotal("Alan",P5);
       calc.findTotal("Ulises",P6);
       calc.findTotal("Alan",P7);
       calc.findTotal("Ulises",P8);
    }    
}

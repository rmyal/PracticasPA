
package tip03;

public class Calculator {
    public double tax = .05;
    public double tip = .15;
    
    /**
     *
     * @param name
     * @param price
     */
    public void findTotal(String name, double price){
        double total = price*(1+tax+tip);
        String format = String.format("%.2f", total);
        System.out.println("Lo que va a pagar "+name+" es $" +format);

    }
}

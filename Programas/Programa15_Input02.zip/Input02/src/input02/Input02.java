package input02;

import javax.swing.JOptionPane;

public class Input02 {
    public static void main(String[] args) {
        
        JOptionPane.showMessageDialog(null,
                "Mensaje de prueba",
                "Programación avanzada",
                3);

        
        String input1 = (String)JOptionPane.showInputDialog(null,
                "Pan de dulce favorito?",
                "PanCuesta",
                2,
                null,
                null,
                null);
        
        
        String[] acceptableValues = {"Café", "Té", "Agua"};
        String input2 = (String)JOptionPane.showInputDialog(null,
                "Bebida favorita",
                "fuente de sodas",
                2,
                null,
                acceptableValues,
                acceptableValues[1]);
                
    }
}

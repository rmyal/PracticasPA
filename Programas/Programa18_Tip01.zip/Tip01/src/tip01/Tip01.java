
package tip01;

public class Tip01 {
    public static void main(String[] args) {
        //Find everyone's indivudlal total after tax(5%) and tip(15%)
        double tax=.05;
        double tip= .15;
        double total;
        int P1=10;
        int P2=12;
        int P3=9;
        int P4=8;
        int P5=7;
        int P6=15;
        int P7=11;
        int P8=30;
        //Persona 1
        total=(P1*tax)+(P1*tip)+P1;
        System.out.println("El pago de la persona 1 con impuestos y propina es: "+total);
        
        //Persona 2
        total=(P2*tax)+(P2*tip)+P2;
        System.out.println("El pago de la persona 2 con impuestos y propina es: "+total);
        
        //Persona 3
        total=(P3*tax)+(P3*tip)+P3;
        System.out.println("El pago de la persona 3 con impuestos y propina es: "+total);
        
        //Persona 4
        total=(P4*tax)+(P4*tip)+P4;
        System.out.println("El pago de la persona 4 con impuestos y propina es: "+total);
        
        //Persona 5
        total=(P5*tax)+(P5*tip)+P5;
        System.out.println("El pago de la persona 5 con impuestos y propina es: "+total);
        
        //Persona 6
        total=(P6*tax)+(P6*tip)+P6;
        System.out.println("El pago de la persona 6 con impuestos y propina es: "+total);
        
        //Persona 7
        total=(P7*tax)+(P7*tip)+P7;
        System.out.println("El pago de la persona 7 con impuestos y propina es: "+total);
        
        //Persona 8
        total=(P8*tax)+(P8*tip)+P8;
        System.out.println("El pago de la persona 8 con impuestos y propina es: "+total);          

    }    
}

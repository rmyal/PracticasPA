
package com.example;

import java.util.*;


public class SquareRootWhile {
    public static void main(String args[])
    {
    System.out.print("Type a non-negative integer: ");
     Scanner console = new Scanner(System.in);
	int number = console.nextInt();
        while(number <= -1){
            System.out.println("Por favor, escriba un número positivo ");
            number = console.nextInt();
    }
        System.out.println("Su raíz cuadrada es: "+Math.sqrt(number));
	
    
}
    
}

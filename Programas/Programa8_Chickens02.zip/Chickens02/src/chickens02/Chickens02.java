
package chickens02;

public class Chickens02 {
    public static void main(String[] args) {
        double monthlyProfit, monthlyAverage, dailyAverage, huevos;
        //lunes, recoge 100
        huevos=100;
        //Martes, recoge 121
        huevos=121+huevos;
        //Miércoles, recoge 117
        huevos=117+huevos;
        //Cálculo de huevos diarios
        dailyAverage=huevos/3;
        //Cálculo de huevos mensuales
        monthlyAverage=dailyAverage*30;
        //Beneficio por los huevos
        monthlyProfit=monthlyAverage*.18;
        System.out.println("Daily Average:   " +dailyAverage);
        System.out.println("Monthly Average: " +monthlyAverage);
        System.out.println("Monthly Profit:  $" +monthlyProfit);
    }
    
}

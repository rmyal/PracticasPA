package input03;
import java.util.Scanner;

class Input03 {

    public static void main(String[] args) {
        //Create a Scanner
        Scanner entrada=new Scanner(System.in);
        //Find and print the sum of three integers entered by the user
        int n1, n2, n3, suma;
        //System.out.println(entrada.nextInt());
        n1=entrada.nextInt();
        //System.out.println(entrada.nextInt());
        n2=n1+entrada.nextInt();
        //System.out.println(entrada.nextInt());
        n3=n2+entrada.nextInt();
        System.out.println(n3);
        //Remember to close the Scanner
          entrada.close();
    }
}

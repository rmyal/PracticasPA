package input01;
import javax.swing.JOptionPane;
public class Input01 {
    public static void main(String[] args) {
        //Create a JOptionPane.
        //Store the input as a String and print it.
        String respuesta = JOptionPane.showInputDialog("Escribe un número");
        
        
        //Parse the input as an int.
        //Print its value +1
        int input = Integer.parseInt(respuesta);
        input++;
        System.out.println(input);
             
    }
}
